#include <iostream>
#include <windows.h>

typedef int(*DeviceOpen)();
typedef void(*MouseDown)(int);
typedef void(*MouseUp)(int);
typedef void(*KeyDown)(int);
typedef void(*KeyUp)(int);
typedef void(*MoveR)(int, int, bool);

HINSTANCE hDll;
bool gmok;
DeviceOpen device_open;
MouseDown mouse_down;
MouseUp mouse_up;
KeyDown key_down;
KeyUp key_up;
MoveR moveR;

void loadFunctions() {
    hDll = LoadLibrary(TEXT("C:/Users/Administrator/source/repos/Projec_yolov5/Projec_yolov5/ghub_device4.dll"));
    if (!hDll) {
        std::cout << "ȱ���ļ�" << std::endl;
        return;
    }

    device_open = (DeviceOpen)GetProcAddress(hDll, "device_open");
    mouse_down = (MouseDown)GetProcAddress(hDll, "mouse_down");
    mouse_up = (MouseUp)GetProcAddress(hDll, "mouse_up");
    key_down = (KeyDown)GetProcAddress(hDll, "key_down");
    key_up = (KeyUp)GetProcAddress(hDll, "key_up");
    moveR = (MoveR)GetProcAddress(hDll, "moveR");

    if (!device_open || !mouse_down || !mouse_up || !key_down || !key_up || !moveR) {
        std::cout << "������ʧ��" << std::endl;
        return;
    }

    gmok = device_open() == 1;
    if (!gmok) {
        std::cout << "δ��װghub����lgs����!!!" << std::endl;
    }
    else {
        std::cout << "��ʼ���ɹ�!" << std::endl;
    }
}

// ����ƶ�
void mouse_xy(int x, int y, bool abs_move = false) {
    if (gmok) {
        moveR(x, y, abs_move);
    }
}

int main() {
    loadFunctions();
    if (gmok) {
        std::cout << "���� mouse_xy ������" << std::endl;
        mouse_xy(200, 100, false);
        std::cout << "����ƶ���(100, 200)" << std::endl;
    }

    if (hDll) {
        FreeLibrary(hDll);
    }


    std::cin.get();
    return 0;
}
